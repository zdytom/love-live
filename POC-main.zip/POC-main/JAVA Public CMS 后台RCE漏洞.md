## JAVA Public CMS 后台RCE漏洞
```
下载地址：https://github.com/sanluan/PublicCMS/
```

## 漏洞复现
![](./assets/20231030204825883.png)

![](./assets/20231030205452844.png)

![](./assets/20231030205817368.png)

![](./assets/20231030205843222.png)

## 环境搭建和复现
```
https://mp.weixin.qq.com/s/MHNVFo6EK8CZtelMaGOBxA
```
