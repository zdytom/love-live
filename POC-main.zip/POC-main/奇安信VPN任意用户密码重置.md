## 奇安信VPN任意用户密码重置


## 漏洞exp
`https://github.com/adeljck/QAX_VPN_Crack`
